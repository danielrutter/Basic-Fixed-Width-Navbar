<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Basic Fixed Width Navbar - 25th February 2017</title>
<link rel="stylesheet" type="text/css" href="/css/global/main.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>

<!-- File Location: /index.php -->

<br>

<nav>
  <ul>
    <li><a href="#" onclick="return false">LINK 1</a></li>
    <li><a href="#" onclick="return false">LINK 2</a></li>
    <li><a href="#" onclick="return false">LINK 3</a></li>
    <li><a href="#" onclick="return false">LINK 4</a></li>
    <li><a href="#" onclick="return false">LINK 5</a></li>
    <li><a href="#" onclick="return false">LINK 6</a></li>
    <li><a href="#" onclick="return false">LINK 7</a></li>
    <li><a href="#" onclick="return false">LINK 8</a></li>
  </ul> 
</nav>

<br>

</body>
</html>
